## Skill information

- Skill name: `ninetoothed-operator-dev-skill`
- Competition: 2026 Spring AI Contest
- Track: NineToothed `.skill` Innovation Challenge
- Problem ID: `T3-1-1`
- Participant: 刘李宏
- Registered team: `123123`
- GitHub ID: `Dreamt-Deer-Waking-Fish`
- Branch: `2026-spring-dreamt-deer-waking-fish-t3-1-1`
- Skill path: `skills/competition/ninetoothed-operator-dev-skill/`

## Scope

This skill guides AI coding agents through NineToothed operator development, testing, debugging, benchmarking, and integration. It covers elementwise/broadcast, reduction/blocking, non-contiguous/stride/offset tasks, performance regression analysis, generated-source/AOT triage, failing-test diagnosis, and minimal patch validation.

## Evidence boundaries

This submission does not contain hidden evaluation answers, hard-coded hidden task names, private credentials, API keys, test-bypass logic, or online-only dependencies. It does not claim broad performance speedup. Full AOT runtime completion, generated-source runtime coverage, InfiniCore native dispatch, and hidden-task success are not claimed where not verified.

## Self-test summary

1. Elementwise / broadcast: Add and ReLU correctness, plus a real Add timing record.
2. Reduction / blocking: Softmax correctness and a real Softmax timing record.
3. Layout-sensitive: non-contiguous, stride, and offset workflow; repaired layout patch validated in the recorded server environment.
4. Performance / AOT / integration: patch checks, fallback diagnosis, and explicit runtime blockers.
5. Production implementation case: production wrapper/test change with focused validation and a cleanly applicable patch.

## Test results

Commands executed from the final skill directory:

```text
python -B -m unittest discover -s tests -v
python -B -m pytest tests -q
python -B scripts/validate_skill_package.py --strict-identity .
python -B scripts/check_no_secrets.py .
python -B scripts/check_false_verified_claims.py .
python -B scripts/check_markdown_links.py .
python -B scripts/verify_manifest.py .
```

`pytest` output:

```text
....................                                                           [100%]
20 passed, 66 subtests passed in 1.53s
```

## Benchmark summary

- Add: shape `(1024, 1024)`, `float32`, contiguous, PyTorch baseline, 10 warmup and 30 measured repeats.
- Softmax: shape `(64, 1024)`, `float32`, contiguous, PyTorch baseline, 10 warmup and 30 measured repeats.
- Both records include correctness gates and raw samples.
- On the selected inputs, the ntops path was slower than the PyTorch baseline; this submission does not claim broad speedup.

## Skill vs no-skill comparison

The comparison uses the same task family, repository context, and controlled workflow where possible. The skill improves contract extraction, repository routing, evidence boundaries, minimal patch checks, and failure-closure discipline. Mixed or negative results are retained and described as limitations rather than rewritten as success.

## Signed disclosures

- Honor code: `skills/competition/ninetoothed-operator-dev-skill/HONOR_CODE.md`
- References and AI disclosure: `skills/competition/ninetoothed-operator-dev-skill/REFERENCE.md`

## Stage reports

- Proposal: `123123_九齿skill创新挑战_proposal.pdf`, SHA-256 `fb5bf06ea9c9f98e1cc09fd307c62bf58901dc33495a3edd5b50369c0b83e513`. Included in the InfiniTensor final submission bundle; GitHub CLI does not provide PR attachment upload.
- Midterm report: `123123_九齿skill创新挑战_中期报告.pdf`, SHA-256 `4eed971b7e7a15303c29408532d5aa4b9dfcdd6e9df2e427cca1a0b66c24e0e0`. Included in the InfiniTensor final submission bundle; GitHub CLI does not provide PR attachment upload.
- Final report: `skills/competition/ninetoothed-operator-dev-skill/reports/123123_九齿skill创新挑战_T3-1-1_赛题报告.pdf`

## Compliance

- [x] No API keys or credentials
- [x] No hidden answers or hard-coded evaluation task names
- [x] No deleted, weakened, or bypassed tests
- [x] No fabricated benchmark results
- [x] External references, dependencies, and AI assistance are disclosed

## Source package integrity

Final signed source ZIP SHA-256:

`7f05d70db8d0734f02cf53b51abb372ee5f4fcb044c76b3b88209e26fb739849`

Submitted commit archive ZIP SHA-256:

`90090d67bc0174cadd18405a83f11e9a3f11fb00651a4e11d45c6924fa7e2976`
