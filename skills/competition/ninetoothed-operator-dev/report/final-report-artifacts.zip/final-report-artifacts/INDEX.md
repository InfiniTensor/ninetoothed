# Final-report artifacts — index

All real (non-`--fake`) GPU episode data pulled from the AutoDL host, organized by session.
Every episode's `skill_engagement` field (in the journals) records the exact Claude Code
session transcript path — cross-reference into `claude-session-transcripts/` for full
tool-call trajectories.

## 2026-07-12-deepseek-v4pro/ — this session, DeepSeek-v4-pro[1m] via Claude Code CLI, new architecture

| Path | What it is | Episodes |
|------|-----------|----------|
| `smoketest/` + `smoketest.csv` | First real post-rollback smoke test | 1 (`ew01` v0, scored 9/10) |
| `engagement-test/` + `engagement-test.jsonl/csv` | End-to-end proof the `skill_engagement` trajectory check works on the real pipeline | 2 (`ew01` no_skill + v0) |
| `deepseek-v4pro-newarch-COMPLETE-24of24/` | **The core with/without-skill comparison** — `run_comparison.sh` blocks 1+2 (6 elementwise + 6 perf_diag tasks × {no_skill, v0}) | COMPLETE — all 24 episodes (re-synced after the run finished) |
| `bench-rerun-5090/` | Fresh RTX 5090 re-run of examples 02/04 benchmarks (2026-07-12, with warmup) | — |
| `claude-session-transcripts/` | Every episode's full Claude Code session transcript (every tool call, every file read) — includes both this session's and the 2026-07-10 session's | 59 sessions total |

Read `deepseek-v4pro-newarch-COMPLETE-24of24/journal.jsonl` for the actual rubric scores —
one JSON object per episode, fields: `scores` (six sub-scores), `rubric_total`, `reward`,
`cost` (tokens/wall time), `skill_engagement` (verified Skill-tool/skill-path usage),
`artifacts.workspace` (path to the agent's produced files, inside the same pull).

## 2026-07-10-glm-qwen14b-earlier-session/ — an earlier session, GLM-5.2 + Qwen2.5-Coder-14B

Discovered still on the host while pulling today's data — not part of this session's work,
included because it's the source of the earlier "33%→100%" decisive result referenced in
project history. Multiple journals for different solver/config combinations:

| File | Solver/config |
|------|---------------|
| `nt-run/journal_glm.jsonl` | GLM-5.2 |
| `nt-run/journal_14b.jsonl` | Qwen2.5-Coder-14B |
| `nt-run/journal_cf.jsonl` | "correctness-feedback" variant |
| `nt-run/journal_b.jsonl`, `journal_b2.jsonl` | version-B evolution runs |
| `nt-run/journal.jsonl`, `journal2.jsonl` | baseline runs |
| `nt-gold/`, `nt-skill/`, `nt-skill-b/`, `nt-skill-bg/` | per-episode workspaces referenced by the above journals |

If this turns out not to be wanted for the final report, it's self-contained in this one
folder and safe to delete without touching the 2026-07-12 data.

## Reading a journal quickly

```bash
python3 -c "
import json
for l in open('<journal.jsonl>'):
    r = json.loads(l)
    if r.get('kind') == 'episode':
        print(r['task_id'], r['mode'], 'total=' + str(r['rubric_total']),
              'engaged=' + str(r.get('skill_engagement', {}).get('engaged')))
"
```

Also: `2026-07-10-glm-qwen14b-earlier-session/logs/` — primary run logs incl. `cc_glm52_repo.log`, the first-hand record of the decisive GLM-5.2 A/B (ops 33%→100%).
