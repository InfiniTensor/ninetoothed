# wrapper.py
import ninetoothed
import ninetoothed.language as ntl
from ninetoothed import Symbol, Tensor, block_size
import torch

BLOCK_SIZE = Symbol("BLOCK_SIZE", constexpr=True)

def arrangement(a, b, mask, output, BM=Symbol("BM", constexpr=True), BN=Symbol("BN", constexpr=True)):
    return (a.tile((BM, 1)), b.tile((1, BN)), mask.tile((BM, BN)), output.tile((BM, BN)))

def application(a, b, mask, output):
    output = ntl.where(mask > 0, a + b, a)  # noqa: F841

kernel = ninetoothed.make(arrangement, application, (Tensor(1), Tensor(1), Tensor(1), Tensor(1)))

def solve(a, b, mask):
    output = torch.empty_like(a)
    kernel.launch(a, b, mask, output, BLOCK_SIZE=block_size())
    return output
