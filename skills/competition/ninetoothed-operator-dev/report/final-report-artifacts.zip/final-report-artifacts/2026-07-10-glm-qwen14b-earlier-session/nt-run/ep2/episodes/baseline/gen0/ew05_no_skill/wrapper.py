import ninetoothed as nt
import torch

def solve(x: torch.Tensor, block_size: int) -> torch.Tensor:
    if x.dtype == torch.float32:
        dtype = 'float32'
    elif x.dtype == torch.float16:
        dtype = 'float16'
    else:
        raise ValueError("Unsupported dtype")

    arrangement = nt.arrangement(nt.tensor(dtype=dtype))
    application = nt.application(silu_kernel)
    kernel = nt.make(arrangement, application, (nt.Tensor(2),))

    # Allocate output tensor
    out = torch.empty_like(x)

    # Launch kernel
    kernel(x, out, BLOCK_SIZE=block_size)

    return out

# Define the SiLU kernel
@nt.kernel
def silu_kernel(x, out):
    i, j = nt.index()
    out[i, j] = x[i, j] * nt.sigmoid(x[i, j])
