import numpy as np
import ninetoothed as nt

def solve(a, b, BLOCK_SIZE):
    if a.dtype == np.float32 or a.dtype == np.float16:
        output = np.empty_like(a)
        kernel = nt.make(
            lambda a, b: (nt.tile(a, (BLOCK_SIZE,)), nt.tile(b, (BLOCK_SIZE,))),
            lambda tiled_a, tiled_b: tiled_a + tiled_b,
            (nt.Tensor(1), nt.Tensor(1))
        )
        kernel(a, b, output=output, BLOCK_SIZE=BLOCK_SIZE)
        return output
    else:
        raise ValueError("Unsupported dtype. Only fp32 and fp16 are supported.")
