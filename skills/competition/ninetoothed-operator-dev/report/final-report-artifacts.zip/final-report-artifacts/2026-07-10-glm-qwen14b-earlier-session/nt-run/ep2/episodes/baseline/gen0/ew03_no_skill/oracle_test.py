# AUTO-GENERATED oracle test — do not edit. Correctness of the agent's `solve`
# against the proxy task reference. Independent of the agent's own test.
import sys, itertools, pathlib
import pytest, torch

_PROXY = pathlib.Path('/root/nt-skill/evaluation/proxy_tasks')
sys.path.insert(0, str(_PROXY))
sys.path.insert(0, str(pathlib.Path(__file__).parent))   # for wrapper.py

pytestmark = pytest.mark.skipif(not torch.cuda.is_available(), reason="no CUDA")

_MERE_THRESH = {"float32": 1.22e-4, "float16": 9.77e-4, "bfloat16": 7.81e-3}

def _load_task():
    from loader import load_all
    for t in load_all():
        if t.id == 'ew03':
            return t
    raise RuntimeError("task ew03 not found")

def _mere_mare(got, ref):
    got = got.float(); ref = ref.float()
    eps = 1e-8
    rel = (got - ref).abs() / (ref.abs() + eps)
    return rel.mean().item(), rel.max().item()

@pytest.mark.parametrize("dtype", ['float32', 'float16'])
def test_oracle(dtype):
    task = _load_task()
    from wrapper import solve as _solve
    inputs = task.make_inputs(device="cuda", dtype=dtype)
    ref = task.reference(*[x.clone() for x in inputs])
    got = _solve(*[x.clone() for x in inputs])
    assert torch.is_tensor(got), "solve did not return a tensor"
    assert got.shape == ref.shape, f"shape {got.shape} != {ref.shape}"
    thr = _MERE_THRESH.get(dtype, 1e-3)
    mere, mare = _mere_mare(got, ref)
    assert mere < thr and mare < 10 * thr, f"MERE={mere:.2e} MARE={mare:.2e} thr={thr:.2e}"
