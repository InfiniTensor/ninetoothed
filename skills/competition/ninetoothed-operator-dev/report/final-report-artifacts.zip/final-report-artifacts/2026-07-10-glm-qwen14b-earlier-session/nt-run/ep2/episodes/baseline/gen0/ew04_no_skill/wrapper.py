import numpy as np

def gelu(x):
    # tanh approximation for GELU
    cdf = 0.5 * (1 + np.tanh(0.7978845608 * (x + 0.044715 * (x ** 3))))
    return x * cdf

def solve(input_tensor, BLOCK_SIZE=256):
    if input_tensor.dtype == np.float16:
        input_tensor = input_tensor.astype(np.float32)
    
    output_tensor = np.empty_like(input_tensor)
    output_tensor[:] = gelu(input_tensor)
    
    if input_tensor.dtype == np.float16:
        output_tensor = output_tensor.astype(np.float16)
    
    return output_tensor
