import numpy as np
import ninetoothed as nt

def application(a, b, mask, out):
    out[mask] = a[mask] + b[mask]

def solve(a, b, mask):
    if a.ndim != 2 or b.ndim != 2 or mask.ndim != 1:
        raise ValueError("Inputs must have shapes (M, N) for a and b, and (1, N) for mask.")
    
    M, N = a.shape
    out = np.empty_like(a)
    
    block_size = min(M, N)
    kernel = nt.make(
        lambda a, b, mask: (a.tile((1,)), b.tile((1,)), mask.tile((1,))),
        application,
        (nt.Tensor(2), nt.Tensor(2), nt.Tensor(1), nt.Tensor(2))
    )
    kernel(a, b, mask, out, BLOCK_SIZE=block_size)
    
    return out
