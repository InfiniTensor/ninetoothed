import torch
def solve(a, b, mask):
    return torch.where(mask.expand_as(a) != 0, a + b, a)
