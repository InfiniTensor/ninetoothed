import itertools, pytest, torch
from wrapper import masked_add

pytestmark = pytest.mark.skipif(not torch.cuda.is_available(), reason='no CUDA')

@pytest.mark.parametrize('n,dtype', list(itertools.product([1024,4096,10000],[torch.float32,torch.float16])))
def test_masked_add(n, dtype):
    a=torch.randn(n,device='cuda',dtype=dtype); b=torch.randn(1,device='cuda',dtype=dtype)
    m=(torch.rand(n,device='cuda')>0.5)
    out=masked_add(a,b,m)
    ref=torch.where(m, a+b.expand_as(a), torch.zeros_like(a))
    assert torch.allclose(out,ref,atol=1e-2,rtol=1e-2)
