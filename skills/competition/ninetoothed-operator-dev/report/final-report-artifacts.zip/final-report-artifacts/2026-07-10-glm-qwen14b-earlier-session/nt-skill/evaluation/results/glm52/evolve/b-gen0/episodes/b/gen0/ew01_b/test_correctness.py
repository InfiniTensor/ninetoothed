"""Correctness tests for the NineToothed 1D elementwise-addition kernel.

Covers >=3 shapes x 2 dtypes (fp32, fp16), including a non-power-of-two shape
and edge cases (size 1, large size).
"""

import pytest
import torch

from wrapper import solve

SHAPES = [
    (1024,),       # power of two, exact tile multiple
    (1025,),       # non-power-of-two (boundary tile)
    (4096,),       # multiple full tiles
    (1,),           # single element
    (100003,),      # large, non-power-of-two
]

DTYPES = [torch.float32, torch.float16]


@pytest.mark.parametrize("shape", SHAPES)
@pytest.mark.parametrize("dtype", DTYPES)
def test_add_correctness(shape, dtype):
    torch.manual_seed(0)
    a = torch.randn(shape, device="cuda", dtype=dtype)
    b = torch.randn(shape, device="cuda", dtype=dtype)

    out = solve(a, b)
    ref = a + b

    # Elementwise addition is a single op; tight tolerance is appropriate.
    # fp16 has ~3 decimal digits, so use a modest atol/rtol.
    atol = 1e-3 if dtype == torch.float32 else 1e-2
    rtol = 1e-3 if dtype == torch.float32 else 1e-2
    assert torch.allclose(out, ref, atol=atol, rtol=rtol), (
        f"Mismatch for shape={shape}, dtype={dtype}: "
        f"max_abs_err={(out - ref).abs().max().item()}"
    )


@pytest.mark.parametrize("dtype", DTYPES)
def test_add_dtype_preserved(dtype):
    a = torch.randn((2048,), device="cuda", dtype=dtype)
    b = torch.randn((2048,), device="cuda", dtype=dtype)
    out = solve(a, b)
    assert out.dtype == dtype
    assert out.shape == a.shape


def test_add_non_contiguous_flattened():
    """Ensure correctness when given a non-contiguous 1D view (flattened)."""
    torch.manual_seed(1)
    base = torch.randn((4096,), device="cuda", dtype=torch.float32)
    # Strided view -> non-contiguous; flatten to make it 1D contiguous for kernel.
    a = base[::2].contiguous()
    b = torch.randn_like(a)
    out = solve(a, b)
    ref = a + b
    assert torch.allclose(out, ref, atol=1e-5, rtol=1e-5)
