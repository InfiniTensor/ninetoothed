"""
1-D elementwise add:  out = a + b.

operation : out[i] = a[i] + b[i]
shapes    : a, b same-shape 1-D tensors
dtypes    : fp32, fp16  (output dtype follows a.dtype)

Design notes
------------
* Pure elementwise: tile a, b, out identically on a flat 1-D grid; one program
  per BLOCK_SIZE tile and one tile element == one output element.
* No cancellation / accumulation, so no fp16 upcast is needed (see
  references/elementwise.md "fp16 / bf16 numeric care").
* Non-divisible shapes: tiles can overrun the tensor edge, so the source
  `Tensor`s carry `other=0.0` — out-of-range loads read a defined value and
  out-of-range stores are masked. This keeps `debug_arrangement` OOB-free.
"""

import ninetoothed
from ninetoothed import Symbol, Tensor

BLOCK_SIZE = Symbol("BLOCK_SIZE", constexpr=True)


def arrangement(a, b, out, BLOCK_SIZE=BLOCK_SIZE):
    """Tile all three tensors identically: one flat tile per program."""
    return (
        a.tile((BLOCK_SIZE,)),
        b.tile((BLOCK_SIZE,)),
        out.tile((BLOCK_SIZE,)),
    )


def application(a, b, out):
    out = a + b  # noqa: F841  (assign to the output param; F841 is expected)


# 1-D symbolic tensors; OOB lanes default to 0.0 so non-divisible shapes are safe.
_TENSORS = (Tensor(1, other=0.0), Tensor(1, other=0.0), Tensor(1, other=0.0))

kernel = ninetoothed.make(arrangement, application, _TENSORS)
