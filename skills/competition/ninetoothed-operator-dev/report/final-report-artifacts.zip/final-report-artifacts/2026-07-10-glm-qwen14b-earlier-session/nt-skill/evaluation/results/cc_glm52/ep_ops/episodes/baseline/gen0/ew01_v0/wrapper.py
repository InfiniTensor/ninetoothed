"""
PyTorch-facing wrapper for the 1-D elementwise add kernel.

The grader entry point is `solve(*inputs)`: pass (a, b) -> out = a + b.
"""

import torch

import kernel as _kernel_module  # same-directory import (files live in CWD)

_kernel = _kernel_module.kernel


def _next_pow2(x: int) -> int:
    """Smallest power of two >= x (>= 1)."""
    p = 1
    while p < x:
        p <<= 1
    return p


def solve(*inputs):
    """Compute out = a + b for same-shape 1-D tensors.

    Args:
        *inputs: two tensors (a, b), same shape, 1-D, fp32 or fp16.
    Returns:
        out: 1-D tensor, same shape and dtype as a.
    """
    if len(inputs) != 2:
        raise ValueError(f"solve expects 2 inputs (a, b), got {len(inputs)}")
    a, b = inputs
    if a.shape != b.shape:
        raise ValueError(
            f"a and b must have the same shape, got {tuple(a.shape)} vs {tuple(b.shape)}"
        )
    if a.dim() != 1:
        raise ValueError(f"expected 1-D tensors, got {a.dim()}-D")

    a = a.contiguous()
    b = b.contiguous()

    out = torch.empty_like(a)
    n = a.numel()
    if n == 0:
        return out

    # BLOCK_SIZE: round size up to a power of two, clamped to a sane hardware
    # limit so a single tile can cover a whole row for small inputs while large
    # inputs are split across many programs.
    block = min(_next_pow2(n), 4096)
    _kernel(a, b, out, BLOCK_SIZE=block)
    return out


def add(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    """Convenience alias matching the kernel's name."""
    return solve(a, b)
