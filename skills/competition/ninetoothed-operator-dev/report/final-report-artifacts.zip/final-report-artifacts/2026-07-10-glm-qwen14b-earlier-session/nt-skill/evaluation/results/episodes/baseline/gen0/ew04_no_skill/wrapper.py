import numpy as np
import ninetoothed as nt

@nt.arrangement
def arrangement(x):
    return x.tile((32,))

@nt.application
def gelu_approximation(tiled_x):
    # tanh approximation of GELU
    cdf = 0.5 * (1 + nt.tanh(0.7978845 * (tiled_x + 0.044715 * nt.square(tiled_x))))
    return tiled_x * cdf

gelu_kernel = nt.make(arrangement, gelu_approximation)

def solve(*inputs):
    output_shape = inputs[0].shape
    output = np.empty(output_shape, dtype=inputs[0].dtype)
    
    block_size = 32
    gelu_kernel(*inputs, *output, BLOCK_SIZE=block_size)
    
    return output
