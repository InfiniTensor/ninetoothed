"""Self-contained wrapper exposing ``solve(*inputs)`` for the ReLU kernel.

The grader calls ``solve(x)`` and expects the output tensor.  This module
defines the NineToothed kernel inline (no external import beyond
ninetoothed/torch) so it is fully self-contained.
"""

import torch
import ninetoothed
import ninetoothed.language as ntl
from ninetoothed import Symbol, Tensor

BLOCK_SIZE = Symbol("BLOCK_SIZE", constexpr=True)


def arrangement(input, output, BLOCK_SIZE=BLOCK_SIZE):
    return input.tile((BLOCK_SIZE,)), output.tile((BLOCK_SIZE,))


def application(input, output):
    output = ntl.maximum(input, 0.0)  # noqa: F841


# other=0.0 ensures OOB reads on non-divisible shapes are well-defined.
kernel = ninetoothed.make(
    arrangement, application, (Tensor(1, other=0.0), Tensor(1))
)


def solve(*inputs):
    """Compute ReLU elementwise: out = max(x, 0).

    Args:
        *inputs: A single tensor ``x`` (any shape, contiguous or not).

    Returns:
        Output tensor with the same shape and dtype as ``x``.
    """
    x = inputs[0]
    # Flatten to 1-D so the 1-D tiled kernel handles arbitrary shapes.
    x_flat = x.contiguous().flatten()
    out_flat = torch.empty_like(x_flat)
    kernel(x_flat, out_flat, BLOCK_SIZE=1024)
    return out_flat.view_as(x)
