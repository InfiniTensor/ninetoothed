"""Correctness tests for the NineToothed ReLU kernel.

Covers >= 3 shapes x 2 dtypes (fp32, fp16), including a non-power-of-two
shape and a non-contiguous input.
"""

import pytest
import torch

from wrapper import solve

DTYPES = [torch.float32, torch.float16]

SHAPES = [
    (1024,),               # power of two, 1-D
    (37, 53),              # non-power-of-two, 2-D
    (128, 256, 16),        # 3-D
]


@pytest.mark.parametrize("dtype", DTYPES)
@pytest.mark.parametrize("shape", SHAPES)
def test_relu_contiguous(shape, dtype):
    """ReLU on contiguous tensors of various shapes and dtypes."""
    torch.manual_seed(0)
    x = torch.randn(shape, dtype=dtype, device="cuda")
    expected = torch.relu(x)
    result = solve(x)

    assert result.dtype == x.dtype
    assert result.shape == x.shape
    assert result.is_contiguous()
    atol = 1e-3 if dtype == torch.float16 else 1e-5
    rtol = 1e-3 if dtype == torch.float16 else 1e-5
    assert torch.allclose(result, expected, atol=atol, rtol=rtol), (
        f"ReLU mismatch for shape={shape}, dtype={dtype}"
    )


@pytest.mark.parametrize("dtype", DTYPES)
def test_relu_non_contiguous(dtype):
    """ReLU on a non-contiguous (transposed) input."""
    torch.manual_seed(42)
    x = torch.randn(64, 128, dtype=dtype, device="cuda").t()
    assert not x.is_contiguous()
    expected = torch.relu(x)
    result = solve(x)

    assert result.dtype == x.dtype
    assert result.shape == x.shape
    atol = 1e-3 if dtype == torch.float16 else 1e-5
    assert torch.allclose(result, expected, atol=atol, rtol=rtol)


@pytest.mark.parametrize("dtype", DTYPES)
def test_relu_all_negative(dtype):
    """ReLU on all-negative values (should produce all zeros)."""
    x = -torch.ones((512,), dtype=dtype, device="cuda")
    expected = torch.relu(x)
    result = solve(x)

    assert result.dtype == x.dtype
    atol = 1e-3 if dtype == torch.float16 else 1e-5
    assert torch.allclose(result, expected, atol=atol, rtol=0.0)
