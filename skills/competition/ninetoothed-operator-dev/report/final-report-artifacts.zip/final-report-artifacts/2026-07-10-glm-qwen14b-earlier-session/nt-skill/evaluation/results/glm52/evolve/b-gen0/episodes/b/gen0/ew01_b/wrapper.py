"""Self-contained wrapper exposing `solve(*inputs)` for 1D elementwise addition.

The grader calls `solve(a, b)` and expects the output tensor `a + b`.
"""

import torch
import ninetoothed
import ninetoothed.language as ntl
from ninetoothed import Symbol, Tensor

BLOCK_SIZE = Symbol("BLOCK_SIZE", constexpr=True)


def arrangement(input, other, output, BLOCK_SIZE=BLOCK_SIZE):
    return (
        input.tile((BLOCK_SIZE,)),
        other.tile((BLOCK_SIZE,)),
        output.tile((BLOCK_SIZE,)),
    )


def application(input, other, output):
    output = input + other  # noqa: F841


# `other=0.0` on source tensors -> OOB loads read 0.0 for non-divisible shapes.
kernel = ninetoothed.make(
    arrangement,
    application,
    (Tensor(1, other=0.0), Tensor(1, other=0.0), Tensor(1)),
)


def solve(*inputs):
    """Compute out = a + b for two same-shape 1D tensors.

    Args:
        inputs: (a, b) two 1D tensors of identical shape.

    Returns:
        A 1D tensor of the same shape and dtype as the inputs.
    """
    a, b = inputs
    output = torch.empty_like(a)
    kernel(a, b, output, BLOCK_SIZE=1024)
    return output
