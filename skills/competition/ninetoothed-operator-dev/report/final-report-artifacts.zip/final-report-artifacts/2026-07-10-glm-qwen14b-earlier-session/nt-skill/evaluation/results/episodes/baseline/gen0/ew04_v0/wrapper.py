import ninetoothed
import ninetoothed.language as ntl
from ninetoothed import Symbol, Tensor, block_size
import torch

BLOCK_SIZE = Symbol("BLOCK_SIZE", constexpr=True)

def arrangement(input, output, BLOCK_SIZE=BLOCK_SIZE):
    return (input.tile((BLOCK_SIZE,)),
            output.tile((BLOCK_SIZE,)))

def application(input, output):
    tanh_x = torch.tanh(input * torch.sqrt(0.5 / torch.pi))
    output = 0.5 * input * (1 + tanh_x)  # noqa: F841

kernel = ninetoothed.make(arrangement, application, tuple(Tensor(1) for _ in range(2)))

def solve(input):
    output = torch.empty_like(input)
    kernel(input, output, BLOCK_SIZE=1024)
    return output
