"""NineToothed kernel for ReLU: out = max(x, 0).

Elementwise 1-D family: input and output are tiled identically along a flat
1-D grid.  The wrapper flattens N-D contiguous tensors before calling the
kernel and reshapes the result back.
"""

import ninetoothed
import ninetoothed.language as ntl
from ninetoothed import Symbol, Tensor

BLOCK_SIZE = Symbol("BLOCK_SIZE", constexpr=True)


def arrangement(input, output, BLOCK_SIZE=BLOCK_SIZE):
    """Tile input and output into 1-D blocks of BLOCK_SIZE."""
    return input.tile((BLOCK_SIZE,)), output.tile((BLOCK_SIZE,))


def application(input, output):
    """Per-tile ReLU: out = max(x, 0)."""
    output = ntl.maximum(input, 0.0)  # noqa: F841


# Tensor(1, other=0.0): OOB loads on non-divisible shapes read 0.0, which is
# the correct ReLU fill value (max(0, 0) = 0).  Output stores are masked by
# NineToothed automatically.
kernel = ninetoothed.make(
    arrangement, application, (Tensor(1, other=0.0), Tensor(1))
)
