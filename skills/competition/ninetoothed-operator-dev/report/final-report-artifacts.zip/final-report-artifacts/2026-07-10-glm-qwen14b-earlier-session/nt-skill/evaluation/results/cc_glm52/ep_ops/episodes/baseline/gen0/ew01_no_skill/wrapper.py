"""Wrapper exposing ``solve(*inputs)`` for 1-D elementwise addition.

The grader calls ``solve(a, b)`` and expects the output tensor ``a + b``.
Inputs are flattened to contiguous 1-D tensors before entering the kernel
(NineToothed auto-masks the tail), and the result is reshaped back to the
original input shape. Both ``fp32`` and ``fp16`` are supported by the same
generated kernel.
"""

import torch

from kernel import kernel  # noqa: E402  (module-level import of generated kernel)


def solve(*inputs, block_size: int = 1024):
    """Compute ``out = a + b`` for same-shape 1-D tensors ``a`` and ``b``.

    :param a, b: same-shape 1-D torch tensors (fp32 or fp16).
    :return: a 1-D tensor of ``a + b`` with the same dtype and shape as ``a``.
    """
    if len(inputs) != 2:
        raise ValueError(f"solve expects exactly 2 inputs (a, b), got {len(inputs)}")

    a, b = inputs

    if a.shape != b.shape:
        raise ValueError(
            f"a and b must have the same shape, got {tuple(a.shape)} vs {tuple(b.shape)}"
        )
    if a.dtype != b.dtype:
        raise ValueError(
            f"a and b must have the same dtype, got {a.dtype} vs {b.dtype}"
        )
    if a.dim() != 1:
        raise ValueError(f"inputs must be 1-D, got {a.dim()}-D")

    # Operate on contiguous flattened data so the kernel deals with plain 1-D.
    a_flat = a.contiguous().flatten()
    b_flat = b.contiguous().flatten()
    out_flat = torch.empty_like(a_flat)

    kernel(a_flat, b_flat, out_flat, BLOCK_SIZE=block_size)

    return out_flat.view_as(a)


def reference(a, b):
    """Reference implementation for correctness checks."""
    return a + b
